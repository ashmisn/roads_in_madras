import sys
import os
import json
import datetime
from typing import List, Dict, Any, Optional

# --- Add project root to path ---
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)
# --------------------------------

try:
    # Use relative import assuming agent.py is in src/
    from . import config, tools, prompts
except ImportError:
    # Fallback for running script directly or different structure
    try:
        from src import config, tools, prompts
    except ImportError:
        import config
        import tools
        import prompts

from langchain_ollama.chat_models import ChatOllama
from langchain_core.prompts import ChatPromptTemplate, PromptTemplate
from langchain_core.runnables import RunnablePassthrough, RunnableBranch, RunnableLambda
from langchain_core.output_parsers import StrOutputParser


# --- 1. Initialize the LLM ---
# --- Corrected LLM Initialization ---
try:
    # 1. Ensure you import the correct class for the LLM variable
    from langchain_ollama.chat_models import ChatOllama
    
    # 2. Assign the ChatOllama class to the global 'llm' variable
    # NOTE: You should use config.OLLAMA_MODEL here for consistency with your agent code
    llm = ChatOllama(base_url="http://localhost:11434", model=config.OLLAMA_MODEL) 
    
    # Or, if config.OLLAMA_MODEL is defined as "phi3:medium" but you want to hardcode the URL:
    # llm = ChatOllama(base_url="http://localhost:11434", model="phi3:medium")

    print(f"LLM initialized with model: {config.OLLAMA_MODEL}")
    
except Exception as e:
    print(f"--- ERROR initializing LLM: {e} ---")
    print(f"Ensure Ollama is running and the model '{config.OLLAMA_MODEL}' is pulled.")
    sys.exit(1)

# --- 2. Knowledge Gap Logger ---
def log_knowledge_gap(query: str):
    """Logs a user query that returned no results to the knowledge gap file."""
    try:
        os.makedirs(os.path.dirname(config.KNOWLEDGE_GAP_LOG_PATH), exist_ok=True)
        with open(config.KNOWLEDGE_GAP_LOG_PATH, "a") as f:
            timestamp = datetime.datetime.now().isoformat()
            f.write(f"[{timestamp}] {query}\n")
        print(f"Logged knowledge gap for query: {query}")
    except Exception as e:
        print(f"Error logging knowledge gap: {e}")
    # Return the specific message expected by downstream chains
    return "No information found in the database for this query."

# --- 3. The "General Query" Chain ---

# --- Planner Prompt ---
try:
    PLANNER_SYSTEM_PROMPT = prompts.PLANNER_SYSTEM_PROMPT
except AttributeError:
    print("--- ERROR: PLANNER_SYSTEM_PROMPT not found in prompts module ---")
    PLANNER_SYSTEM_PROMPT = "Error: Planner prompt missing." # Basic fallback


# --- execute_plan Function (DEFINITIVE FIX) ---
def execute_plan(input_dict: dict) -> dict:
    """
    Executes planned search AND keyword search (with category hint),
    FUSES the results using RRF, and passes the top N
    to the synthesis step.
    Returns dict with context and query.
    """
    agent_plan = input_dict.get('plan', None)
    
    # 1. Extract the raw input and ensure it is always a string (CRITICAL FIX)
    raw_input = input_dict.get('query', "Query unavailable")
    
    # Define query_string as the guaranteed clean input string for all subsequent steps
    # This check prevents the AttributeError: 'dict' object has no attribute 'lower'
    if isinstance(raw_input, dict):
        query_string = raw_input.get('query', "Query unavailable")
    elif isinstance(raw_input, str):
        query_string = raw_input
    else:
        # Fallback for unexpected types
        query_string = str(raw_input) 

    if not agent_plan:
        print("Error: Agent Plan is missing.")
        return {"context": log_knowledge_gap(query_string), "query": query_string}

    planned_results = []
    tool_map = {
        "structured_search": tools.structured_search,
        "semantic_search": tools.semantic_search,
    }
    
    # --- Use a slightly larger k for initial retrieval ---
    INITIAL_K = 7

    print(f"\n--- Executing General Plan (Hybrid Search + RRF) ---")
    print(f"Planner Thought: {getattr(agent_plan, 'thought', 'N/A')}")

    # --- Step 1: Execute Planned Search (Semantic/Structured) ---
    plan_steps = getattr(agent_plan, 'plan', [])
    if not isinstance(plan_steps, list): plan_steps = []

    for tool_call in plan_steps:
        if not (hasattr(tool_call, 'tool_name') and hasattr(tool_call, 'arguments')):
            print(f"Warning: Invalid tool_call format: {tool_call}")
            continue
        tool_name = tool_call.tool_name
        arguments = tool_call.arguments
        tool_function = tool_map.get(tool_name)
        if tool_function:
            try:
                print(f"Calling (Planner): {tool_name} with args {arguments}")
                if not isinstance(arguments, dict):
                    print(f"Warning: Invalid arguments format for {tool_name}: {arguments}")
                    continue
                if tool_name == "semantic_search":
                    search_query = arguments.get('query')
                    if not search_query:
                        print("Warning: Missing 'query' argument for semantic_search.")
                        continue
                    result = tool_function(query=search_query, n_results=INITIAL_K)
                elif tool_name == "structured_search":
                    valid_args = {k: v for k, v in arguments.items() if k in ['problem', 'category', 'type'] and v}
                    if not valid_args:
                        print(f"Warning: No valid arguments provided for structured_search: {arguments}")
                        continue
                    result = tool_function(**valid_args)
                else:
                    print(f"Warning: Unknown tool name '{tool_name}' encountered in plan.")
                    continue
                if result is not None and isinstance(result, list):
                    planned_results.extend(result)
                elif result is not None:
                    print(f"Warning: Tool {tool_name} returned non-list result: {result}")
            except Exception as e:
                print(f"--- Error executing planned tool {tool_name}: {e} ---")
        else:
            print(f"Warning: Planned tool '{tool_name}' not found in tool_map.")
    print(f"Planned search returned {len(planned_results)} results.")

    # --- Step 2: Execute Keyword Search (WITH CATEGORY HINT) ---
    keyword_results = []
    try:
        # Use the guaranteed string variable: query_string
        print(f"Calling (Keyword): keyword_search_sqlite for query '{query_string}'") 
        if hasattr(tools, 'extract_keywords_and_category') and hasattr(tools, 'keyword_search_sqlite'):
            
            # Pass the guaranteed string: query_string
            extracted_keywords, guessed_category = tools.extract_keywords_and_category(query_string)
            
            if extracted_keywords:
                # Pass the guaranteed string: query_string
                keyword_results = tools.keyword_search_sqlite(query=query_string, category_hint=guessed_category, n_results=INITIAL_K)
            else:
                print("No keywords extracted, skipping keyword search.")
        else:
            print("Error: Keyword search or extraction function not found in tools module.")
    except Exception as e:
        print(f"Error during keyword search execution: {e}")
        import traceback
        traceback.print_exc()

    # --- Step 3: Call RRF Fusion (NEW) ---
    print("Fusing planned results and keyword results with RRF...")
    
    hybrid_results_list = [
        {"semantic": planned_results, "keyword": keyword_results}
    ]
    
    fused_results = []
    if hasattr(tools, 'rrf_fuse'):
        try:
            fused_results = tools.rrf_fuse(hybrid_results_list)
        except Exception as e:
            print(f"Error during RRF fusion: {e}")
            # Fallback to simple combine
            fused_results = planned_results + keyword_results
    else:
        print("Warning: 'rrf_fuse' function not found in tools.py. Falling back to simple combination.")
        fused_results = planned_results + keyword_results

    # --- Step 4: Deduplicate Fused Results (NEW) ---
    final_deduped_results = []
    seen_ids = set()
    for res in fused_results:
        doc_id = res.get('S. No.')
        if doc_id is not None:
            try:
                doc_id_int = int(doc_id)
                if doc_id_int not in seen_ids:
                    final_deduped_results.append(res)
                    seen_ids.add(doc_id_int)
            except (ValueError, TypeError):
                print(f"Warning: Invalid 'S. No.' format encountered: {doc_id}. Skipping.")

    # --- Step 5: Select Top N Results ---
    FINAL_CONTEXT_K = 7
    final_results = final_deduped_results[:FINAL_CONTEXT_K]

    print(f"RRF selected top {len(final_results)} unique results to send to LLM.")
    print("----------------------------------------------------------\n")

    # --- Step 6: Format Final Context ---
    if not final_results:
        context_str = log_knowledge_gap(query_string)
    else:
        try:
            context_str = json.dumps(final_results, indent=2)
        except TypeError as e:
            print(f"Error serializing final results to JSON: {e}")
            context_str = "\n---\n".join([str(item) for item in final_results])

    # Return the guaranteed string variable: query_string
    return {"context": context_str, "query": query_string}


# --- create_general_query_chain (Uses the new execute_plan) ---
def create_general_query_chain():
    """Builds the chain for handling general queries using planning, RRF, and synthesis."""
    try:
        agent_plan_schema = prompts.AgentPlan
        final_answer_prompt_template = prompts.FINAL_ANSWER_PROMPT
    except AttributeError as e:
        print(f"--- ERROR: Missing Pydantic model or prompt in prompts module: {e} ---")
        agent_plan_schema = None
        final_answer_prompt_template = "Error: Synthesis prompt missing. Context: {context} Query: {query}"
        sys.exit(1)

    # 1. Planner sub-chain
    plan_chain = (
        ChatPromptTemplate.from_template(PLANNER_SYSTEM_PROMPT)
        | llm.with_structured_output(agent_plan_schema)
    )

    # 2. Synthesis sub-chain
    synthesis_chain = (
        PromptTemplate.from_template(final_answer_prompt_template)
        | llm
        | StrOutputParser()
    )

    # 3. Complete chain structure: Plan -> Execute (Hybrid, RRF) -> Synthesize
    complete_general_chain = RunnablePassthrough.assign(
        plan= RunnableLambda(lambda x: {"query": x["query"]}) | plan_chain
    ) | execute_plan | synthesis_chain

    return complete_general_chain


# --- create_extractor_chain (Unchanged) ---
def create_extractor_chain():
    """Builds the chain for extracting specific facts (uses semantic search k=1)."""
    try:
        extractor_output_schema = prompts.ExtractorOutput
        extractor_prompt_template = prompts.EXTRACTOR_PROMPT
    except AttributeError as e:
        print(f"--- ERROR: Missing Pydantic model or prompt in prompts module: {e} ---")
        extractor_output_schema = None
        extractor_prompt_template = "Error: Extractor prompt missing. Context: {context} Query: {query}"
        sys.exit(1)

    def semantic_search_tool_for_extractor(input_dict: dict) -> str:
        query = input_dict.get("query", "")
        print(f"\n--- Executing Extractor Search ---")
        try:
            if hasattr(tools, 'semantic_search'):
                # --- CRITICAL: n_results=1 ---
                results = tools.semantic_search(query=query, n_results=1)
            else:
                print("Error: semantic_search function not found in tools module.")
                results = []
            print(f"Found {len(results)} extraction context.")
            if not results:
                log_knowledge_gap(query)
                return "[[EXTRACTION_CONTEXT_NOT_FOUND]]"
            try:
                context_str = json.dumps(results, indent=2)
            except TypeError:
                context_str = str(results) 
            return context_str
        except Exception as e:
            print(f"Error in extractor semantic search: {e}")
            return "[[EXTRACTION_CONTEXT_NOT_FOUND]]"

    def format_extractor_output(output: Any) -> str: 
        if not isinstance(output, extractor_output_schema):
            print(f"Warning: Extractor LLM did not return expected Pydantic object. Output: {output}")
            if isinstance(output, str) and "not found" in output.lower():
                return "I could not find a specific answer for that in the database."
            return "Could not extract the answer due to an internal formatting error."

        if output.answer is None or "not found" in output.answer.lower():
            return "I could not find a specific answer for that in the database."
        source_str = ""
        if output.source_code and output.source_clause:
            source_str = f" (Source: {output.source_code}, Clause: {output.source_clause})"
        elif output.source_code:
            source_str = f" (Source: {output.source_code})"
        return f"The answer is: **{output.answer}**{source_str}"

    extractor_prompt_obj = ChatPromptTemplate.from_template(extractor_prompt_template)

    def route_extractor_logic(input_dict: dict):
        context = input_dict.get("context", "")
        if context == "[[EXTRACTION_CONTEXT_NOT_FOUND]]":
            return RunnableLambda(lambda x: "I could not find relevant context in the database for that specific query.")
        else:
            extractor_llm_chain = extractor_prompt_obj | llm.with_structured_output(extractor_output_schema, include_raw=False) | format_extractor_output
            return extractor_llm_chain

    # Final extractor chain structure
    return (
        {"context": semantic_search_tool_for_extractor, "query": lambda x: x["query"]}
        | RunnableLambda(route_extractor_logic)
    )


# --- create_supervisor_chain (Unchanged) ---
def create_supervisor_chain():
    """Builds the master chain that routes tasks."""
    try:
        query_router_schema = prompts.QueryRouter
        router_prompt_template = prompts.ROUTER_PROMPT
    except AttributeError as e:
        print(f"--- ERROR: Missing Pydantic model or prompt in prompts module: {e} ---")
        query_router_schema = None
        router_prompt_template = "Error: Router prompt missing. Query: {query}"
        sys.exit(1)

    router_prompt_obj = ChatPromptTemplate.from_template(router_prompt_template)
    router_chain = router_prompt_obj | llm.with_structured_output(query_router_schema)

    general_chain = create_general_query_chain()
    extractor_chain = create_extractor_chain()

    branch = RunnableBranch(
        (lambda x: x.get('task_type') == 'extraction_query', extractor_chain),
        general_chain
    )

    return (
        {"task": {"query": RunnablePassthrough()} | router_chain,
         "query": RunnablePassthrough()}
        | RunnableLambda(lambda x: {"task_type": getattr(x.get("task"), "task_type", "general_query"), "query": x.get("query")})
        | branch
    )

# --- Main execution block (Consolidated for Array Testing and File Output) ---
if __name__ == "__main__":
    
    OUTPUT_FILENAME = "agent_test_outputnewmodel.txt"
    
    # 1. Open the file handle for writing
    try:
        output_file = open(OUTPUT_FILENAME, "w", encoding="utf-8")
        def write_and_print(text):
            print(text, end="", flush=True)
            output_file.write(text)
            
    except Exception as e:
        print(f"FATAL ERROR: Could not open output file {OUTPUT_FILENAME}: {e}")
        sys.exit(1)


    write_and_print("Road Safety Supervisor Agent Initialized. (Testing Mode)\n")
    write_and_print(f"Writing all test output to: {OUTPUT_FILENAME}\n")

    if tools.sql_engine is None or tools.langchain_vector_store is None:
        write_and_print("\n--- WARNING: One or more tools failed to initialize. ---\n")

    try:
        agent_chain = create_supervisor_chain()
    except Exception as e:
        write_and_print(f"--- FATAL ERROR during agent chain creation: {e} ---\n")
        import traceback
        traceback.print_exc(file=output_file) # Also write traceback to file
        sys.exit(1)

    # --- Test Queries Array (Unchanged) ---
    TEST_QUERIES = [
        "What is the minimum spacing between two successive signs on interurban roads?",
        "What is the size of the STOP sign for a design speed of 55 km/h?",
        "What is the required clear visibility distance for a Gap in Median Sign when the approach speed is 75 km/h?",
        "What should the width of the Continuous Center Line Marking be, and what color should it be?",
        "What is the recommended radius for a Speed Hump designed for a target speed of 30 km/h?",
        "List all the common problems related to STOP Signs and their corresponding IRC clauses.",
        "Summarize all the different ways the height of a road sign is regulated.",
        "Explain the placement rules for Bi-Directional road studs on a four-lane divided road in a No-Overtaking section.",
        "I found a Transverse Bar Marking installed d1= 40 m from a hazard on a road with 70 km/h approach speed. Is this compliant?",
        "What are the general rules for Wrongly Placed signs?",
        "What are the regulations for a Guardrail Delineator?",
        "Is a traffic lane line that is 150 mm wide compliant?",
        "For a 'Hospital Sign', what is the area of the normal size sign and the area of the small size sign in square millimeters?",
        "I want to put a box marking at an un-signalised roundabout. What are the rules for this?",
        "What are the placement rules for a 'Gap in Median' sign on a 90 km/h road, and how do these differ from a 'Narrow Bridge' sign at the same speed?",
        "What is the 'clear visibility distance' for a 'U-Turn Prohibited Sign'?",
        "There is an object hazard on the left side of my road, but it's on a sharp curve with a speed of 90 km/h. What signs and markings are needed, and what are their placement distances?"
    ]
    # --------------------------
    
    # --- Loop over the test queries array ---
    for query in TEST_QUERIES:
        if query.lower() == 'exit':
            write_and_print("\nExiting based on 'exit' query in the test array.\n")
            break
            
        write_and_print(f"\n==================================================")
        write_and_print(f"\n🚀 Running Query: {query}")
        write_and_print(f"\n==================================================\n")

        try:
            write_and_print("\n--- Agent Answer ---\n")
            full_response = ""
            
            # STREAMING: Write each chunk to both console and file
            for chunk in agent_chain.stream({"query": query}): 
                write_and_print(chunk) 
                full_response += chunk
                
            write_and_print("\n--------------------\n")

        except Exception as e:
            write_and_print(f"\n--- An Error Occurred During Query Processing ---")
            write_and_print(f"\nQuery: {query}")
            write_and_print(f"\nError Type: {type(e).__name__}")
            write_and_print(f"\nError Details: {e}")
            
            # Print and write the traceback to both destinations
            import traceback
            traceback.print_exc(file=sys.stdout)
            traceback.print_exc(file=output_file)

            write_and_print(f"\n-------------------------------------------------\n")
            
    write_and_print("\nRoad Safety Supervisor Agent Testing Complete.\n")
    
    # 2. Close the file handle
    output_file.close()